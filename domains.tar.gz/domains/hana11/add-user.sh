#!/bin/sh


. ./env.sh

$INFINISPAN_HOME/bin/add-user.sh
