#!/bin/sh


. ./env.sh

tail -f $LOG_DIR/server.log
