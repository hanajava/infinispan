echo num1:
read num1
echo num2:
read num2

let re=num1+num2 #Add
echo "add:=$re"
let re=num1-num2 #Sub
echo "sub:=$re"
let re=num1*num2 #Mul
echo "mul:=$re"
let re=num1/num2 #Div
echo "div:=$re"
let re=num1%num2 #Mod
echo "mod:=$re"
