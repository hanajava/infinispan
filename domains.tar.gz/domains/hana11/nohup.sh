#!/bin/sh


. ./env.sh

tail -f $LOG_DIR/nohup/nohup.out
